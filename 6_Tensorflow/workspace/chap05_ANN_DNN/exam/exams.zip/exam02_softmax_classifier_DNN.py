'''
문) wine data set을 이용하여 다음과 같이 DNN 모델을 생성하시오.
  <조건1>   
   - Hidden layer : relu()함수 이용  
   - Output layer : softmax()함수 이용 
   - 2개의 은닉층을 갖는 DNN 분류기
     hidden1 : nodes = 6
     hidden2 : nodes = 3  
  <조건2> hyper parameters
    learning_rate = 0.01
    iter_size = 1,000
  <조건3>  
    train/test(80:20)
    x_data : 정규화 
    y_data : one-hot encoding
'''

import tensorflow.compat.v1 as tf # ver1.x
tf.disable_v2_behavior() # ver2.0 사용안함
from sklearn.datasets import load_wine # data set
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import minmax_scale

# 1. wine data load
wine = load_wine()

# 2. 변수 선택/전처리  
x_data = wine.data # 178x13
y_data = wine.target # 3개 domain
print(y_data) # 0-2
print(x_data.shape) # (178, 13)

# x_data : 정규화 
x_data = minmax_scale(x_data) # 0~1

# y변수 one-hot-encoding : 0=[1,0,0] / 1=[0,1,0] / 2=[0,0,1]
num_class = np.max(y_data)+1 # 2+1
print(num_class) # 3

y_data = np.eye(num_class)[y_data]
print(y_data.shape) # (178, 3)

# 4. train/test split
x_train, x_test, y_train, y_test = train_test_split(
    x_data, y_data, test_size=0.2, random_state=123)

# 5. X,Y 변수 정의  
X = tf.placeholder(tf.float32, shape=[None, 13]) # [n, 13개 원소]
Y = tf.placeholder(tf.float32, shape=[None, 3]) # [n, 3개 원소]

# 6. Hypter parameters
learning_rate = 0.01
iter_size = 1000
    
##############################
### DNN network
##############################


