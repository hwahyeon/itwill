# -*- coding: utf-8 -*-
"""
문) 다음과 같이 Celeb image의 분류기(classifier)를 생성하시오.  
   조건1> train image : train_celeb4
   조건2> validation image : val_celeb4
   조건3> image shape : 120 x 120
   조건4> Image Data Generator 이용 image 자료 생성 
   조건5> model layer 
         1. Convolution layer1 : [4,4,3,32]
         2. Convolution layer2 : [4,4,32,64]
         3. Flatten layer
         4. DNN hidden layer1 : 64
         5. DNN hidden layer2 : 32
         6. DNN output layer : 10
   조건6> 기타 나머지는 step04 참고       
"""
from tensorflow.keras import Sequential # keras model 
from tensorflow.keras.layers import Conv2D, MaxPool2D,Activation
from tensorflow.keras.layers import Dense, Flatten 
import os

# images dir 
base_dir = "./"
train_dir = os.path.join(base_dir, 'train_celeb4')
val_dir = os.path.join(base_dir, 'val_celeb4')


# 1. CNN Model layer 



# 2. image file preprocessing : 이미지 제너레이터 이용  



# 3. model training : 이미지 제너레이터 객체 이용  



# 4. model history graph