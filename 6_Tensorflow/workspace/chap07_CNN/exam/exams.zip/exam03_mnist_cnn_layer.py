'''
exam_mnist_cnn_layer
 ppt-p.31 내용으로 CNN model를 설계하시오.
'''

import tensorflow.compat.v1 as tf # ver1.x
tf.disable_v2_behavior() # ver2.0 사용안함

from tensorflow.keras.datasets.mnist import load_data # ver2.0 dataset
from tensorflow.keras.utils import to_categorical
from sklearn.metrics import accuracy_score
import numpy as np

# minst data read
(x_train, y_train), (x_test, y_test) = load_data()
print(x_train.shape) # (60000, 28, 28)
print(y_train.shape) # (60000,) : 10진수 
print(x_test.shape) # (10000, 28, 28)
print(y_test.shape) # (10000,) : 10진수 

# image data reshape : [s, h, w, c]
x_train = x_train.reshape(-1, 28, 28, 1)
x_test = x_test.reshape(-1, 28, 28, 1)
print(x_train.shape) # (60000, 28, 28, 1)

# x_data : int -> float
x_train = x_train.astype('float32')
x_test = x_test.astype('float32')
print(x_train[0]) # 0 ~ 255

# x_data : 정규화 
x_train /= 255 # x_train = x_train / 255
x_test /= 255
print(x_train[0])

# y_data : 10 -> 2(one-hot)
y_train = to_categorical(y_train)
y_test = to_categorical(y_test)

# hyper parameters
learning_rate = 0.001
epochs = 15
batch_size = 100
iter_szie = int(60000 / batch_size) # 600

# X, Y 변수 정의 
X_img = tf.placeholder(tf.float32, shape=[None, 28, 28, 1]) # (?, 784)
Y = tf.placeholder(tf.float32, shape=[None, 10]) # (?, 10)


